"""
Configuration Loader for Canada Ontario Scraper (Platform Config Integration)

This module provides centralized config and path management for Canada Ontario scraper.
Integrates with platform_config.py to read from config/CanadaOntario.env.json.

Precedence (highest to lowest):
1. Runtime overrides
2. Environment variables (OS-level)
3. Platform config (config/CanadaOntario.env.json)
4. Hardcoded defaults
"""
import sys
from pathlib import Path
from typing import Optional

# Add repo root to path for platform_config import
# Now: scripts/Canada Ontario/config_loader.py -> parents[2] = repo root
_repo_root = Path(__file__).resolve().parents[2]
if str(_repo_root) not in sys.path:
    sys.path.insert(0, str(_repo_root))

_CONFIG_MANAGER_AVAILABLE = False


def get_repo_root() -> Path:
    """Get repository root directory (parent of scraper directories)."""
    if _CONFIG_MANAGER_AVAILABLE:
        return ConfigManager.get_app_root()
    return _repo_root


def get_central_output_dir() -> Path:
    """Get central exports directory for final reports - uses exports/CanadaOntario/"""
    pm = get_path_manager()
    exports_dir = pm.get_exports_dir(SCRAPER_ID)  # Scraper-specific exports
    exports_dir.mkdir(parents=True, exist_ok=True)
    return exports_dir

# Try to import platform_config (preferred)
try:
    from platform_config import PathManager, ConfigResolver, get_path_manager, get_config_resolver
    _PLATFORM_CONFIG_AVAILABLE = True
except ImportError:
    _PLATFORM_CONFIG_AVAILABLE = False
    PathManager = None
    ConfigResolver = None
    def get_path_manager():  # type: ignore[override]
        if _CONFIG_MANAGER_AVAILABLE:
            class _FallbackPathManager:
                @staticmethod
                def get_platform_root() -> Path:
                    return ConfigManager.get_app_root()

                @staticmethod
                def get_config_dir() -> Path:
                    return ConfigManager.get_config_dir()

                @staticmethod
                def get_input_dir(scraper_id: str) -> Path:
                    return ConfigManager.get_input_dir(scraper_id)

                @staticmethod
                def get_output_dir(scraper_id: Optional[str] = None) -> Path:
                    return ConfigManager.get_output_dir(scraper_id)

                @staticmethod
                def get_backups_dir(scraper_id: Optional[str] = None) -> Path:
                    return ConfigManager.get_backups_dir(scraper_id)

                @staticmethod
                def get_exports_dir(scraper_id: Optional[str] = None) -> Path:
                    return ConfigManager.get_exports_dir(scraper_id)

                @staticmethod
                def get_runs_dir() -> Path:
                    return ConfigManager.get_runs_dir()

                @staticmethod
                def get_run_dir(scraper_id: str, run_id: str) -> Path:
                    run_dir = ConfigManager.get_runs_dir() / run_id
                    (run_dir / "logs").mkdir(parents=True, exist_ok=True)
                    (run_dir / "artifacts").mkdir(parents=True, exist_ok=True)
                    (run_dir / "exports").mkdir(parents=True, exist_ok=True)
                    return run_dir

                @staticmethod
                def get_sessions_dir() -> Path:
                    return ConfigManager.get_sessions_dir()

                @staticmethod
                def get_logs_dir() -> Path:
                    return ConfigManager.get_logs_dir()

                @staticmethod
                def get_cache_dir() -> Path:
                    return ConfigManager.get_cache_dir()

            return _FallbackPathManager
        raise RuntimeError("PathManager unavailable and ConfigManager not loaded")

try:
    from core.config_manager import ConfigManager
    _CONFIG_MANAGER_AVAILABLE = True
except Exception:
    _CONFIG_MANAGER_AVAILABLE = False
    ConfigManager = None

# Scraper ID for this scraper
SCRAPER_ID = "CanadaOntario"


def _ensure_env_loaded() -> None:
    if not _CONFIG_MANAGER_AVAILABLE:
        return
    try:
        ConfigManager.load_env(SCRAPER_ID)
    except FileNotFoundError:
        ConfigManager.ensure_dirs()


def getenv(key: str, default: str = None) -> str:
    """
    Get environment variable with fallback to default.
    Integrates with platform_config if available.
    Checks both 'config' and 'secrets' sections.

    Args:
        key: Environment variable name
        default: Default value if not found

    Returns:
        Environment variable value or default (always as string)
    """
    _ensure_env_loaded()
    if _CONFIG_MANAGER_AVAILABLE:
        value = ConfigManager.get_env_value(SCRAPER_ID, key, default if default is not None else "")
        if value not in ("", None):
            return value
    if _PLATFORM_CONFIG_AVAILABLE:
        cr = get_config_resolver()
        val = cr.get(SCRAPER_ID, key, None)
        if val is not None:
            return str(val)
        secret_val = cr.get_secret_value(SCRAPER_ID, key, "")
        if secret_val:
            return secret_val
    return default if default is not None else ""


def getenv_int(key: str, default: int = 0) -> int:
    """Get environment variable as integer."""
    try:
        val = getenv(key, str(default))
        return int(val)
    except (ValueError, TypeError):
        return default


def getenv_float(key: str, default: float = 0.0) -> float:
    """Get environment variable as float."""
    try:
        val = getenv(key, str(default))
        return float(val)
    except (ValueError, TypeError):
        return default


def getenv_bool(key: str, default: bool = False) -> bool:
    """Get environment variable as boolean."""
    val = getenv(key, "")
    
    # Handle case where val might already be a boolean (from JSON config)
    if isinstance(val, bool):
        return val
    
    # Convert to string and process
    val_str = str(val).strip().lower()
    if val_str in ("1", "true", "yes", "on"):
        return True
    elif val_str in ("0", "false", "no", "off", ""):
        return False
    return default


def get_base_dir() -> Path:
    """
    Get base directory for Canada Ontario scraper.

    With platform_config: Returns platform root
    Legacy mode: Returns parent of scripts folder
    """
    pm = get_path_manager()
    return pm.get_platform_root()


def get_input_dir(subpath: str = None) -> Path:
    """
    Get input directory - uses Documents/ScraperPlatform/input/CanadaOntario/

    Args:
        subpath: Optional subdirectory under input/
    """
    if _PLATFORM_CONFIG_AVAILABLE:
        pm = get_path_manager()
        base = pm.get_input_dir(SCRAPER_ID)  # Scraper-specific input
        base.mkdir(parents=True, exist_ok=True)

    if subpath:
        return base / subpath
    return base


def get_output_dir(subpath: str = None) -> Path:
    """
    Get output directory - uses Documents/ScraperPlatform/output/CanadaOntario/
    
    Scraper-specific output directory for organized file management.

    Args:
        subpath: Optional subdirectory under output/
    """
    # First check if OUTPUT_DIR is explicitly set (absolute path or environment variable)
    output_dir_str = getenv("OUTPUT_DIR", "")
    if output_dir_str and Path(output_dir_str).is_absolute():
        base = Path(output_dir_str)
    else:
        pm = get_path_manager()
        base = pm.get_output_dir(SCRAPER_ID)  # Scraper-specific output
        base.mkdir(parents=True, exist_ok=True)

    if subpath:
        result = base / subpath
        result.mkdir(parents=True, exist_ok=True)
        return result
    return base


def get_backup_dir() -> Path:
    """Get backup directory - uses Documents/ScraperPlatform/output/backups/CanadaOntario/"""
    pm = get_path_manager()
    backup_dir = pm.get_backups_dir(SCRAPER_ID)  # Scraper-specific backups
    backup_dir.mkdir(parents=True, exist_ok=True)
    return backup_dir


def get_logs_dir() -> Path:
    """Get logs directory."""
    pm = get_path_manager()
    return pm.get_logs_dir()


def get_run_id() -> str:
    """Get or generate a run id for this process."""
    run_id = getenv("RUN_ID", "")
    if run_id:
        return run_id
    from datetime import datetime
    return datetime.utcnow().strftime("%Y%m%d_%H%M%S")


def get_run_dir(run_id: Optional[str] = None) -> Path:
    """Get run directory for the current run."""
    pm = get_path_manager()
    run_id = run_id or get_run_id()
    return pm.get_run_dir(SCRAPER_ID, run_id)


def get_proxy_config() -> dict:
    """Get proxy configuration for requests (optional)."""
    proxy_url = getenv("PROXY_URL", "").strip()
    if not proxy_url:
        return {}
    return {"http": proxy_url, "https": proxy_url}


# File names
PRODUCTS_CSV_NAME = getenv("PRODUCTS_CSV_NAME", "products.csv")
MANUFACTURER_MASTER_CSV_NAME = getenv("MANUFACTURER_MASTER_CSV_NAME", "manufacturer_master.csv")

# Final report configuration
FINAL_REPORT_NAME_PREFIX = getenv("FINAL_REPORT_NAME_PREFIX", "canadaontarioreport_")
FINAL_REPORT_DATE_FORMAT = getenv("FINAL_REPORT_DATE_FORMAT", "%d%m%Y")

# EAP prices configuration
EAP_PRICES_URL = getenv("EAP_PRICES_URL", "https://www.ontario.ca/page/exceptional-access-program-product-prices")
EAP_PRICES_CSV_NAME = getenv("EAP_PRICES_CSV_NAME", "ontario_eap_prices.csv")

# Static values
STATIC_CURRENCY = getenv("STATIC_CURRENCY", "CAD")
STATIC_REGION = getenv("STATIC_REGION", "NORTH AMERICA")


# Diagnostic function
if __name__ == "__main__":
    from core.logger import setup_standard_logger
    logger = setup_standard_logger("canada_ontario_config", scraper_name="CanadaOntario")
    logger.info("Canada Ontario Config Loader - Diagnostic")
    logger.info("Platform Config Available: %s", _PLATFORM_CONFIG_AVAILABLE)
    logger.info("Scraper ID: %s", SCRAPER_ID)
    logger.info("Base Dir: %s", get_base_dir())
    logger.info("Input Dir: %s", get_input_dir())
    logger.info("Output Dir: %s", get_output_dir())
    logger.info("Backup Dir: %s", get_backup_dir())
    logger.info("Logs Dir: %s", get_logs_dir())
