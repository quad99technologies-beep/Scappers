#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Argentina - Final export (DB-only).

Reads:
  - ar_products_translated (current run_id)
  - ar_pcid_reference (global)

Writes:
  - alfabeta_Report_<date>_pcid_mapping.csv
  - alfabeta_Report_<date>_pcid_missing.csv
  - alfabeta_Report_<date>_pcid_oos.csv (empty placeholder)
  - alfabeta_Report_<date>_pcid_no_data.csv
"""

from __future__ import annotations

import os
import re
import sys
import unicodedata
from pathlib import Path
from datetime import datetime
from typing import List, Optional

import pandas as pd

from config_loader import (
    get_output_dir,
    get_central_output_dir,
    OUTPUT_REPORT_PREFIX,
    DATE_FORMAT,
    EXCLUDE_PRICE,
)
from core.db.connection import CountryDB
from core.db.models import generate_run_id
from db.schema import apply_argentina_schema
from db.repositories import ArgentinaRepository


def _get_run_id(output_dir: Path) -> str:
    rid = os.environ.get("ARGENTINA_RUN_ID")
    if rid:
        return rid
    run_id_file = output_dir / ".current_run_id"
    if run_id_file.exists():
        txt = run_id_file.read_text(encoding="utf-8").strip()
        if txt:
            return txt
    rid = generate_run_id()
    os.environ["ARGENTINA_RUN_ID"] = rid
    run_id_file.write_text(rid, encoding="utf-8")
    return rid


def parse_money(x: Optional[object]) -> Optional[float]:
    if x is None or (isinstance(x, float) and pd.isna(x)):
        return None
    s = str(x).strip().replace("\u00a0", "")
    if not s:
        return None
    sl = s.lower()
    if sl in {"nan", "none", "null"}:
        return None
    if re.fullmatch(r"\d+(?:\.\d+)?", s):
        try:
            return float(s)
        except Exception:
            return None
    if re.fullmatch(r"\d{1,3}(?:,\d{3})+(?:\.\d+)?", s):
        try:
            return float(s.replace(",", ""))
        except Exception:
            return None
    if re.fullmatch(r"\d{1,3}(?:\.\d{3})+,\d{2}", s):
        try:
            return float(s.replace(".", "").replace(",", "."))
        except Exception:
            return None
    if re.fullmatch(r"\d+,\d{2}", s):
        try:
            return float(s.replace(",", "."))
        except Exception:
            return None
    m = re.search(r"(\d+[.,]?\d*)", s)
    if not m:
        return None
    token = m.group(1)
    if "." in token and "," in token:
        if token.rfind(",") > token.rfind("."):
            token = token.replace(".", "").replace(",", ".")
        else:
            token = token.replace(",", "")
    else:
        if "," in token and "." not in token:
            token = token.replace(",", ".")
    try:
        return float(token)
    except Exception:
        return None


def _norm(s: Optional[str]) -> str:
    return re.sub(r"\s+", " ", str(s).strip().lower()) if s is not None else ""


def normalize_cell(s: Optional[object]) -> Optional[str]:
    if s is None or pd.isna(s):
        return None
    if not isinstance(s, str):
        s = str(s)
    s = s.strip()
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    s = "".join(ch for ch in s if ord(ch) < 128 or ch.isspace())
    return s.strip()


def normalize_df_strings(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for col in df.columns:
        if df[col].dtype == object or str(df[col].dtype) == "string":
            df[col] = df[col].map(normalize_cell)
    return df


def get(row, *names, default=None):
    for n in names:
        if n in row:
            val = row[n]
            if val is None:
                continue
            if isinstance(val, float) and pd.isna(val):
                continue
            sval = str(val).strip()
            if not sval or sval.lower() in {"nan", "none", "null"}:
                continue
            return val
    return default


def compute_ri_fields(row):
    ioma_os = get(row, "ioma_os", "IOMA_OS")
    ioma_af = get(row, "ioma_af", "IOMA_AF")
    pami_af = get(row, "pami_af", "PAMI_AF")
    ioma_detail = get(row, "ioma_detail", "IOMA_detail", default="")
    import_stat = get(row, "import_status", default="")

    def contains(text, *needles):
        try:
            t = str(text).lower()
        except Exception:
            return False
        return any(n.lower() in t for n in needles)

    has_ioma = (ioma_os is not None) or (ioma_af is not None) or contains(ioma_detail, "ioma")
    has_pami = (not has_ioma) and (pami_af is not None)
    is_imported = contains(import_stat, "importado", "imported")

    if has_ioma:
        return "IOMA", parse_money(ioma_os), parse_money(ioma_af), "IOMA-preferred (OS->Reimb, AF->Copay)"
    if has_pami:
        return "PAMI-only", None, parse_money(pami_af), "PAMI-only-AF-as-Copay"
    if is_imported:
        return "IMPORTED", None, None, "Imported-fallback"
    return None, None, None, "No-scheme"


def attach_pcid_strict(df: pd.DataFrame, mapping_df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df = normalize_df_strings(df)

    s_company = df.get("Company", df.get("company"))
    s_lprod = df.get("Local Product Name", df.get("product_name"))
    s_generic = df.get("Generic Name", df.get("active_ingredient"))
    s_desc = df.get("Local Pack Description", df.get("description"))

    df["n_company"] = s_company.map(_norm)
    df["n_lprod"] = s_lprod.map(_norm)
    df["n_generic"] = s_generic.map(_norm)
    df["n_desc"] = s_desc.map(_norm)

    m = normalize_df_strings(mapping_df)
    m["n_company"] = m["company"].map(_norm)
    m["n_lprod"] = m["local_product_name"].map(_norm)
    m["n_generic"] = m["generic_name"].map(_norm)
    m["n_desc"] = m["local_pack_description"].map(_norm)

    key_to_pcid = {
        (r.n_company, r.n_lprod, r.n_generic, r.n_desc): r.pcid
        for _, r in m.iterrows()
        if str(r.pcid or "").strip()
    }

    df["PCID"] = df.apply(
        lambda r: key_to_pcid.get((r["n_company"], r["n_lprod"], r["n_generic"], r["n_desc"]), ""),
        axis=1,
    ).astype("string")

    df.drop(columns=["n_company", "n_lprod", "n_generic", "n_desc"], inplace=True)
    return df


def mapping_rows_to_output(mapping_df: pd.DataFrame, country_value: str, output_cols: List[str]) -> pd.DataFrame:
    def col_or_blank(name: str) -> pd.Series:
        if name in mapping_df.columns:
            return mapping_df[name].astype("string").fillna("")
        return pd.Series([""] * len(mapping_df), index=mapping_df.index, dtype="string")

    out = pd.DataFrame(
        {
            "PCID": col_or_blank("pcid"),
            "Country": country_value,
            "Company": col_or_blank("company"),
            "Local Product Name": col_or_blank("local_product_name"),
            "Generic Name": col_or_blank("generic_name"),
            "Effective Start Date": pd.Series([""] * len(mapping_df), index=mapping_df.index, dtype="string"),
            "Public With VAT Price": pd.Series([""] * len(mapping_df), index=mapping_df.index, dtype="string"),
            "Reimbursement Category": pd.Series([""] * len(mapping_df), index=mapping_df.index, dtype="string"),
            "Reimbursement Amount": pd.Series([""] * len(mapping_df), index=mapping_df.index, dtype="string"),
            "Co-Pay Amount": pd.Series([""] * len(mapping_df), index=mapping_df.index, dtype="string"),
            "Local Pack Description": col_or_blank("local_pack_description"),
        }
    )
    return normalize_df_strings(out.reindex(columns=output_cols))


def main() -> None:
    output_dir = get_output_dir()
    output_dir.mkdir(parents=True, exist_ok=True)
    exports_dir = get_central_output_dir()
    exports_dir.mkdir(parents=True, exist_ok=True)

    run_id = _get_run_id(output_dir)

    db = CountryDB("Argentina")
    apply_argentina_schema(db)
    repo = ArgentinaRepository(db, run_id)

    # Load translated products
    with db.cursor(dict_cursor=True) as cur:
        cur.execute("SELECT * FROM ar_products_translated WHERE run_id = %s", (run_id,))
        rows = cur.fetchall()
    if not rows:
        raise RuntimeError("No translated rows found. Run step 5 first.")

    df = pd.DataFrame(rows)
    df = normalize_df_strings(df)

    # Compute RI fields
    ri = df.apply(
        lambda r: pd.Series(
            compute_ri_fields(r),
            index=["Reimbursement Category", "Reimbursement Amount", "Co-Pay Amount", "rule_label"],
        ),
        axis=1,
    )
    df = pd.concat([df, ri], axis=1)

    # Map to output columns
    df["Country"] = "ARGENTINA"
    df["Company"] = df.get("company")
    df["Local Product Name"] = df.get("product_name")
    df["Generic Name"] = df.get("active_ingredient")
    df["Effective Start Date"] = df.get("date")
    df["Local Pack Description"] = df.get("description")

    if not EXCLUDE_PRICE:
        df["Public With VAT Price"] = df.get("price_ars").apply(parse_money)
    else:
        df["Public With VAT Price"] = pd.NA

    df["Reimbursement Amount"] = df["Reimbursement Amount"].apply(parse_money)
    df["Co-Pay Amount"] = df["Co-Pay Amount"].apply(parse_money)

    # Load PCID reference from DB
    with db.cursor(dict_cursor=True) as cur:
        cur.execute(
            "SELECT pcid, company, local_product_name, generic_name, local_pack_description FROM ar_pcid_reference"
        )
        mapping_rows = cur.fetchall()
    mapping_df = pd.DataFrame(mapping_rows) if mapping_rows else pd.DataFrame(
        columns=["pcid", "company", "local_product_name", "generic_name", "local_pack_description"]
    )

    # Attach PCID (strict 4-key match)
    df = attach_pcid_strict(df, mapping_df)

    output_cols = [
        "PCID",
        "Country",
        "Company",
        "Local Product Name",
        "Generic Name",
        "Effective Start Date",
        "Public With VAT Price",
        "Reimbursement Category",
        "Reimbursement Amount",
        "Co-Pay Amount",
        "Local Pack Description",
    ]
    for c in output_cols:
        if c not in df.columns:
            df[c] = pd.NA

    df_final = normalize_df_strings(df[output_cols].copy())
    print(f"[COUNT] translated_rows={len(df_final)}", flush=True)

    pcid_norm = df_final["PCID"].astype("string").fillna("").str.strip()
    mapped_mask = pcid_norm.ne("")

    df_mapped = df_final[mapped_mask].copy()
    df_missing = df_final[~mapped_mask].copy()

    today_str = datetime.now().strftime(DATE_FORMAT)
    out_prefix = f"{OUTPUT_REPORT_PREFIX}{today_str}"
    out_mapped = output_dir / f"{out_prefix}_pcid_mapping.csv"
    out_missing = output_dir / f"{out_prefix}_pcid_missing.csv"
    out_oos = output_dir / f"{out_prefix}_pcid_oos.csv"
    out_no_data = output_dir / f"{out_prefix}_pcid_no_data.csv"

    df_mapped.to_csv(out_mapped, index=False, encoding="utf-8-sig", float_format="%.2f")
    df_missing.to_csv(out_missing, index=False, encoding="utf-8-sig", float_format="%.2f")
    print(f"[COUNT] mapped={len(df_mapped)} missing={len(df_missing)}", flush=True)

    # OOS not available in DB reference; write empty placeholder
    empty = pd.DataFrame(columns=output_cols)
    empty.to_csv(out_oos, index=False, encoding="utf-8-sig")

    # No-data: reference PCIDs not used in output (strict match)
    used_pcid = set(pcid_norm[mapped_mask].tolist())
    if not mapping_df.empty:
        no_data_mask = mapping_df["pcid"].astype(str).str.strip().ne("") & ~mapping_df["pcid"].isin(used_pcid)
        no_data_df = mapping_rows_to_output(mapping_df[no_data_mask].copy(), "ARGENTINA", output_cols)
    else:
        no_data_df = empty.copy()
    no_data_df.to_csv(out_no_data, index=False, encoding="utf-8-sig", float_format="%.2f")

    # Write to central exports dir
    for out_path in [out_mapped, out_missing, out_oos, out_no_data]:
        try:
            target = exports_dir / out_path.name
            target.write_bytes(out_path.read_bytes())
        except Exception:
            pass

    # Persist mappings in DB (mapped + missing)
    repo.clear_pcid_mappings()
    mapping_rows_to_insert = []
    for _, r in df_final.iterrows():
        mapping_rows_to_insert.append(
            {
                "pcid": r.get("PCID"),
                "company": r.get("Company"),
                "local_product_name": r.get("Local Product Name"),
                "generic_name": r.get("Generic Name"),
                "local_pack_description": r.get("Local Pack Description"),
                "price_ars": r.get("Public With VAT Price") if not EXCLUDE_PRICE else None,
                "source": "PRICENTRIC",
            }
        )
    repo.insert_pcid_mappings(mapping_rows_to_insert)

    # Export report tracking
    repo.log_export_report("pcid_mapping", str(out_mapped), len(df_mapped))
    repo.log_export_report("pcid_missing", str(out_missing), len(df_missing))
    repo.log_export_report("pcid_oos", str(out_oos), len(empty))
    repo.log_export_report("pcid_no_data", str(out_no_data), len(no_data_df))

    # Finish run in run_ledger
    try:
        stats = repo.get_stats()
        repo.finish_run(
            status="completed",
            items_scraped=stats.get("products", 0),
            items_exported=len(df_final),
        )
    except Exception:
        pass

    print(f"[OK] Wrote: {out_mapped}")
    print(f"[OK] Wrote: {out_missing}")
    print(f"[OK] Wrote: {out_oos}")
    print(f"[OK] Wrote: {out_no_data}")


if __name__ == "__main__":
    main()
