"""DB package for Argentina scraper."""

from .schema import apply_argentina_schema  # noqa: F401
