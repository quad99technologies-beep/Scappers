#!/usr/bin/env python3
"""
Base scraper with Playwright stealth context, anti-bot init scripts,
session rotation, and shared DB/run_id management.
"""

import logging
import random
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Optional

from playwright.sync_api import sync_playwright, Browser, BrowserContext, Page, Playwright

logger = logging.getLogger(__name__)

# Stealth init script injected into every Playwright context
_STEALTH_INIT_SCRIPT = """
// Hide webdriver property
Object.defineProperty(navigator, 'webdriver', {
    get: () => undefined,
    configurable: true
});

// Mock plugins array
Object.defineProperty(navigator, 'plugins', {
    get: () => {
        const plugins = [
            {name: 'Chrome PDF Plugin', filename: 'internal-pdf-viewer', description: 'Portable Document Format'},
            {name: 'Chrome PDF Viewer', filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai', description: ''},
            {name: 'Native Client', filename: 'internal-nacl-plugin', description: ''}
        ];
        plugins.length = 3;
        return plugins;
    },
    configurable: true
});

// Mock languages
Object.defineProperty(navigator, 'languages', {
    get: () => ['en-US', 'en'],
    configurable: true
});

// Mock chrome runtime
window.chrome = window.chrome || {};
window.chrome.runtime = window.chrome.runtime || {};
window.chrome.loadTimes = window.chrome.loadTimes || function() {
    return { commitLoadTime: Date.now() / 1000 };
};
window.chrome.csi = window.chrome.csi || function() {
    return { startE: Date.now(), onloadT: Date.now() };
};

// Mock permissions query
if (navigator.permissions) {
    const origQuery = navigator.permissions.query.bind(navigator.permissions);
    navigator.permissions.query = (params) => {
        if (params.name === 'notifications') {
            return Promise.resolve({state: Notification.permission});
        }
        return origQuery(params);
    };
}

// Remove Playwright-specific properties
delete window.__playwright;
delete window.__pw_manual;
"""

# Random user agents pool
_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
]


class BaseScraper:
    """
    Playwright-based scraper with stealth context and session rotation.

    Subclasses implement scraping logic; this class manages browser lifecycle,
    anti-bot measures, and provides human-like action helpers.
    """

    def __init__(self, run_id: str, db, config: dict = None):
        """
        Args:
            run_id: Pipeline run identifier.
            db: CountryDB instance.
            config: Optional config dict (from config_loader).
        """
        self.run_id = run_id
        self.db = db
        self.config = config or {}

        # For Chrome PID tracking (used by the GUI's "Chrome Instances (tracked)" counter)
        # Defaults are derived from this file location: scripts/<ScraperName>/scrapers/base.py
        self.scraper_name = (
            self.config.get("scraper_name")
            or self.config.get("SCRAPER_NAME")
            or self._infer_scraper_name()
        )
        self.repo_root = self._infer_repo_root()
        self._playwright: Optional[Playwright] = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._page_count = 0
        self.max_pages_per_session = int(self.config.get("max_pages_per_session", 50))

    @staticmethod
    def _infer_scraper_name() -> str:
        try:
            # .../scripts/Malaysia/scrapers/base.py -> parents[1] == "Malaysia"
            return Path(__file__).resolve().parents[1].name
        except Exception:
            return "Unknown"

    @staticmethod
    def _infer_repo_root() -> Path:
        try:
            # .../scripts/Malaysia/scrapers/base.py -> parents[3] == repo root
            return Path(__file__).resolve().parents[3]
        except Exception:
            return Path.cwd()

    def _track_playwright_chrome_pids(self) -> None:
        """
        Best-effort: detect and persist Playwright-launched Chrome/Chromium PIDs for GUI tracking.
        """
        try:
            if not self._browser:
                return
            from core.chrome_pid_tracker import (
                get_chrome_pids_from_playwright_browser,
                save_chrome_pids,
            )

            pids = get_chrome_pids_from_playwright_browser(self._browser)
            if pids:
                save_chrome_pids(self.scraper_name, self.repo_root, pids)
        except Exception:
            # Never fail scraping due to optional PID tracking.
            logger.debug("Chrome PID tracking failed (non-fatal)", exc_info=True)

    # ------------------------------------------------------------------
    # Context management
    # ------------------------------------------------------------------

    def _launch_args(self):
        return [
            "--disable-blink-features=AutomationControlled",
            "--disable-dev-shm-usage",
            "--no-sandbox",
            "--disable-setuid-sandbox",
            "--start-maximized",
        ]

    def _context_options(self) -> dict:
        """Return kwargs for browser.new_context()."""
        return {
            "locale": "en-US",
            "timezone_id": "Asia/Kuala_Lumpur",
            "viewport": {"width": 1366, "height": 768},
            "user_agent": random.choice(_USER_AGENTS),
            "extra_http_headers": {
                "Accept-Language": "en-US,en;q=0.9",
                "Accept-Encoding": "gzip, deflate, br",
                "DNT": "1",
            },
            "geolocation": {"latitude": 3.139, "longitude": 101.6869},
            "permissions": ["geolocation"],
        }

    def _create_context(self) -> BrowserContext:
        """Create a new stealth browser context."""
        ctx = self._browser.new_context(**self._context_options())
        ctx.add_init_script(_STEALTH_INIT_SCRIPT)
        self._page_count = 0
        return ctx

    @contextmanager
    def browser_session(self, headless: bool = False):
        """
        Context manager that provides a stealth Playwright page.

        Usage:
            with self.browser_session() as page:
                page.goto("https://example.com")
        """
        self._playwright = sync_playwright().start()
        try:
            self._browser = self._playwright.chromium.launch(
                headless=headless,
                args=self._launch_args(),
            )
            self._track_playwright_chrome_pids()
            self._context = self._create_context()
            page = self._context.new_page()
            self._page_count = 1
            yield page
        finally:
            if self._context:
                self._context.close()
            if self._browser:
                self._browser.close()
            if self._playwright:
                self._playwright.stop()
            self._context = None
            self._browser = None
            self._playwright = None

    def new_page(self) -> Page:
        """Get a new page, rotating context if needed."""
        self._page_count += 1
        if self._page_count > self.max_pages_per_session and self._browser:
            logger.info("Session rotation: creating new context after %d pages",
                        self._page_count - 1)
            old = self._context
            self._context = self._create_context()
            if old:
                old.close()
        return self._context.new_page()

    # ------------------------------------------------------------------
    # Human-like helpers
    # ------------------------------------------------------------------

    @staticmethod
    def pause(min_s: float = 0.3, max_s: float = 1.0):
        """Random pause to mimic human behavior."""
        time.sleep(random.uniform(min_s, max_s))

    @staticmethod
    def long_pause(min_s: float = 1.5, max_s: float = 3.5):
        """Longer pause for page loads."""
        time.sleep(random.uniform(min_s, max_s))

    @staticmethod
    def type_delay_ms() -> int:
        """Random per-character typing delay in ms."""
        return random.randint(50, 150)

    def human_type(self, page: Page, selector: str, text: str):
        """Type text character-by-character with human-like delays."""
        page.locator(selector).click()
        self.pause(0.1, 0.3)
        page.locator(selector).press_sequentially(text, delay=self.type_delay_ms())
        self.pause(0.2, 0.5)

    # ------------------------------------------------------------------
    # Wait helpers
    # ------------------------------------------------------------------

    def wait_for_cloudflare(self, page: Page, timeout_s: float = 90.0):
        """
        Wait for Cloudflare verification to complete.
        Detects challenge pages and waits for them to resolve.
        """
        start = time.time()
        check_interval = 2.0

        while time.time() - start < timeout_s:
            try:
                body_text = page.evaluate("document.body?.innerText || ''").lower()
            except Exception:
                time.sleep(check_interval)
                continue

            is_challenge = any(kw in body_text for kw in [
                "please wait", "verifying", "checking your browser",
                "just a moment", "enable javascript",
            ])

            if not is_challenge:
                logger.info("Cloudflare verification passed (%.1fs)",
                            time.time() - start)
                return True

            time.sleep(check_interval)

        logger.warning("Cloudflare verification timed out after %.0fs", timeout_s)
        return False

    def wait_for_table_stable(self, page: Page, row_selector: str,
                              checks: int = 3, interval: float = 2.0,
                              timeout: float = 60.0) -> int:
        """
        Wait for table row count to stabilize.
        Returns final row count or 0 on timeout.
        """
        start = time.time()
        stable_count = 0
        last_count = -1

        while time.time() - start < timeout:
            try:
                current = page.locator(row_selector).count()
            except Exception:
                current = 0

            if current > 0 and current == last_count:
                stable_count += 1
                if stable_count >= checks:
                    logger.info("Table stable at %d rows after %.1fs",
                                current, time.time() - start)
                    return current
            else:
                stable_count = 0
            last_count = current
            time.sleep(interval)

        logger.warning("Table stability timeout after %.0fs (last count: %d)",
                        timeout, last_count)
        return max(last_count, 0)
