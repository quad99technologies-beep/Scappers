"""Malaysia scraper modules."""
