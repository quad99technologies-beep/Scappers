"""Malaysia pipeline step entry points."""
